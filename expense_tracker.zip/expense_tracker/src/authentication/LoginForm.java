package authentication;

import dashboard.ExpenseTrackerDashboard;
import util.MySQLConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class LoginForm extends JFrame {

    public static Integer userId;
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginForm() {
        setTitle("Expense Tracker - Login");
        setSize(800, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");


        usernameField = new JTextField(50);
        passwordField = new JPasswordField(50);

        JButton loginButton = new JButton("Login");
        JButton signUpButton = new JButton("SignUp Instead?");

        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);

        usernameLabel.setBounds(100, 100, 350, 50);
        usernameLabel.setFont(font1);
        usernameField.setBounds(300, 100, 400, 50);
        usernameField.setFont(font2);

        passwordLabel.setBounds(100, 200, 350, 50);
        passwordLabel.setFont(font1);
        passwordField.setBounds(300, 200, 400, 50);
        passwordField.setFont(font2);

        loginButton.setBounds(100, 350, 250, 50);
        loginButton.setBackground(Color.decode("#2dc460"));
        loginButton.setFont(font1);

        signUpButton.setBounds(400, 350, 300, 50);
        signUpButton.setBackground(Color.decode("#4ba3c4"));
        signUpButton.setFont(font1);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = String.valueOf(passwordField.getPassword());

                if (LoginForm.this.authenticate(username, password)) {
                    ExpenseTrackerDashboard dashboard = new ExpenseTrackerDashboard();
                    dashboard.setVisible(true);

                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Login failed. Please try again.");
                }
            }
        });

        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SignupForm();
                dispose();
            }
        });

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(signUpButton);
        add(panel);
        setVisible(true);
    }

    private boolean authenticate(String username, String password) {
        try {
            Connection connection = MySQLConnection.getConnection();
            Statement statement = connection.createStatement();
            String sqlQuery = "SELECT * FROM users WHERE username = '" +
                    username + "' and password = '" + password + "'";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            if (resultSet.next()) {
                userId = resultSet.getInt(1);
                resultSet.close();
                statement.close();
                connection.close();
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginForm();
            }
        });
    }
}
