package authentication;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Date;

import com.toedter.calendar.JDateChooser;
import util.MySQLConnection;

public class SignupForm extends JFrame {
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JDateChooser dobChooser;
    private JTextField usernameField;
    private JPasswordField passwordField;

    public SignupForm() {
        setTitle("Expense Tracker - Sign Up");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 550);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel firstNameLabel = new JLabel("First Name:");
        JLabel lastNameLabel = new JLabel("Last Name:");
        JLabel dobLabel = new JLabel("Date of Birth:");
        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");

        firstNameField = new JTextField();
        lastNameField = new JTextField();
        dobChooser = new JDateChooser();
        usernameField = new JTextField();
        passwordField = new JPasswordField();

        JButton signUpButton = new JButton("Sign Up");
        JButton loginButton = new JButton("Login Instead?");


        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);

        firstNameLabel.setBounds(100, 35, 350, 40);
        firstNameLabel.setFont(font1);
        firstNameField.setBounds(300, 35, 400, 40);
        firstNameField.setFont(font2);

        lastNameLabel.setBounds(100, 105, 350, 40);
        lastNameLabel.setFont(font1);
        lastNameField.setBounds(300, 105, 400, 40);
        lastNameField.setFont(font2);

        dobLabel.setBounds(100, 175, 350, 40);
        dobLabel.setFont(font1);
        dobChooser.setBounds(300, 175, 400, 40);
        dobChooser.setFont(font2);

        usernameLabel.setBounds(100, 245, 350, 40);
        usernameLabel.setFont(font1);
        usernameField.setBounds(300, 245, 400, 40);
        usernameField.setFont(font2);

        passwordLabel.setBounds(100, 315, 350, 40);
        passwordLabel.setFont(font1);
        passwordField.setBounds(300, 315, 400, 40);
        passwordField.setFont(font2);

        loginButton.setBounds(400, 400, 300, 40);
        loginButton.setBackground(Color.decode("#4ba3c4"));
        loginButton.setFont(font1);

        signUpButton.setBounds(100, 400, 250, 40);
        signUpButton.setBackground(Color.decode("#2dc460"));
        signUpButton.setFont(font1);


        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                java.util.Date dob = dobChooser.getDate();
                String username = usernameField.getText();
                char[] passwordChars = passwordField.getPassword();
                String password = new String(passwordChars);

                if (signUpUser(firstName, lastName, dob, username, password)) {
//                    JOptionPane.showMessageDialog(null, "Registration successful!");
                    new LoginForm();
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Registration failed. Please try again.");
                }
            }
        });


        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginForm();
                dispose();
            }
        });

        panel.add(firstNameLabel);
        panel.add(firstNameField);
        panel.add(lastNameLabel);
        panel.add(lastNameField);
        panel.add(dobLabel);
        panel.add(dobChooser);
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(signUpButton);
        panel.add(loginButton);
        add(panel);
        setVisible(true);
    }

    private boolean signUpUser(String firstName, String lastName, Date dob, String username, String password) {
        if (firstName == null | lastName == null | dob == null | username == null | password == null) {
            return false;
        }
        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "INSERT INTO users (first_name, last_name, dob, username, password) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);
            java.sql.Date sqlDobDate = new java.sql.Date(dob.getTime());
            preparedStatement.setDate(3, sqlDobDate);
            preparedStatement.setString(4, username);
            preparedStatement.setString(5, password);

            int rowsAffected = preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SignupForm signupForm = new SignupForm();
            signupForm.setVisible(true);
        });
    }
}



