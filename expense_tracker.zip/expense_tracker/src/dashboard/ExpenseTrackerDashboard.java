package dashboard;

import panels.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ExpenseTrackerDashboard extends JFrame {
    private JPanel sideMenuPanel;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private DashboardPanel dashboardPanel;
    private ExpensePanel expensePanel;
    private IncomePanel incomePanel;
    private SplitPanel splitPanel;
    private SubscriptionPanel subscriptionPanel;
    private ReportsPanel reportsPanel;
    private SettingPanel settingPanel;

    public ExpenseTrackerDashboard() {
        dashboardPanel = new DashboardPanel();
        expensePanel = new ExpensePanel();
        incomePanel = new IncomePanel();
        splitPanel = new SplitPanel();
        subscriptionPanel = new SubscriptionPanel();
        reportsPanel = new ReportsPanel();
        settingPanel = new SettingPanel();

        setTitle("Expense Tracker - Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 700);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // Side Panel
        sideMenuPanel = new JPanel();
        sideMenuPanel.setLayout(new GridLayout(7, 1));

        JButton dashboardButton = new JButton("Dashboard");
        JButton addExpenseButton = new JButton("Expenses (Debit)");
        JButton addIncomeButton = new JButton("Incomes (Credit)");
        JButton addSplitButton = new JButton("Splits");
        JButton addSubscriptionButton = new JButton("Subscriptions");
        JButton reportsButton = new JButton("Reports");
        JButton settingsButton = new JButton("Settings");

        dashboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "DashboardPanel");
            }
        });

        addExpenseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "Expenses");
                expensePanel.setCategoryComboBox();
            }
        });

        addIncomeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "Incomes");
                incomePanel.setCategoryComboBox();
            }
        });

        addSplitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "Splits");
            }
        });

        addSubscriptionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "Subscriptions");
            }
        });

        reportsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "Reports");
            }
        });

        settingsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "Settings");
            }
        });


        sideMenuPanel.add(dashboardButton);
        sideMenuPanel.add(addExpenseButton);
        sideMenuPanel.add(addIncomeButton);
        sideMenuPanel.add(addSplitButton);
        sideMenuPanel.add(addSubscriptionButton);
        sideMenuPanel.add(reportsButton);
        sideMenuPanel.add(settingsButton);

        mainPanel.add(dashboardPanel, "DashboardPanel");
        mainPanel.add(expensePanel, "Expenses");
        mainPanel.add(incomePanel, "Incomes");
        mainPanel.add(splitPanel, "Splits");
        mainPanel.add(subscriptionPanel, "Subscriptions");
        mainPanel.add(reportsPanel, "Reports");
        mainPanel.add(settingPanel, "Settings");

        cardLayout.show(mainPanel, "DashboardPanel");

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(sideMenuPanel, BorderLayout.WEST);
        getContentPane().add(mainPanel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ExpenseTrackerDashboard dashboard = new ExpenseTrackerDashboard();
            dashboard.setVisible(true);
        });
    }
}