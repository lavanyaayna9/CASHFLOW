package util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static authentication.LoginForm.userId;
import static util.MySQLConnection.getConnection;

public class Categories {
    public static List<String> getCategories(String type) {
        List<String> categories = new ArrayList<>();
        try {
            Connection connection = getConnection();
            String query = "SELECT category_id, category_name FROM categories where category_type = ?" +
                    " and (user_id is null or user_id = ?) ";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, type);
            preparedStatement.setInt(2, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String categoryName = resultSet.getString("category_name");
                categories.add(categoryName);
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categories;
    }

    public static Integer getCategoryIdByName(String name) {
        int categoryId = 0;
        try {
            Connection connection = getConnection();
            String categoryQuery = "SELECT category_id FROM categories" +
                    " WHERE category_name = ? and (user_id = ? or user_id is null)";
            PreparedStatement preparedStatement = connection.prepareStatement(categoryQuery);
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, userId);
            ResultSet categoryResultSet = preparedStatement.executeQuery();

            if (categoryResultSet.next()) {
                categoryId = categoryResultSet.getInt("category_id");
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categoryId;
    }

    public static String getCategoryNameById(int categoryId) {
        String categoryName = "";
        try {
            Connection connection = getConnection();
            String categoryQuery = "SELECT category_name FROM categories" +
                    " WHERE category_id = ? and (user_id = ? or user_id is null)";
            PreparedStatement preparedStatement = connection.prepareStatement(categoryQuery);
            preparedStatement.setInt(1, categoryId);
            preparedStatement.setInt(2, userId);
            ResultSet categoryResultSet = preparedStatement.executeQuery();

            if (categoryResultSet.next()) {
                categoryName = categoryResultSet.getString("category_name");
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categoryName;
    }

    public static List<String> getDefaultCategories() {
        List<String> categories = new ArrayList<>();

        try {
            Connection connection = getConnection();
            String categoryQuery = "SELECT category_name FROM categories WHERE user_id is null";
            PreparedStatement preparedStatement = connection.prepareStatement(categoryQuery);
            ResultSet categoryResultSet = preparedStatement.executeQuery();

            while (categoryResultSet.next()) {
                String categoryName = categoryResultSet.getString("category_name");
                categories.add(categoryName);
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categories;
    }
}
