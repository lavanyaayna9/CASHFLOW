package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLConnection {
    public static Connection getConnection() throws SQLException {
        String jdbcUrl = "jdbc:mysql://localhost:3306/expense_tracker";
        String username = "root";
        String password = "password";

        return DriverManager.getConnection(jdbcUrl, username, password);
    }

}
