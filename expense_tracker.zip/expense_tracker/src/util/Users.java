package util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static util.MySQLConnection.getConnection;

public class Users {
    public static List<String> getAllUserNames() {
        List<String> users = new ArrayList<>();

        try {
            Connection connection = getConnection();
            String categoryQuery = "SELECT username FROM users";
            PreparedStatement preparedStatement = connection.prepareStatement(categoryQuery);
            ResultSet categoryResultSet = preparedStatement.executeQuery();

            while (categoryResultSet.next()) {
                String userName = categoryResultSet.getString("username");
                users.add(userName);
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }

    public static Integer getUserIdByUsername(String name) {
        int userId = 0;
        try {
            Connection connection = getConnection();
            String categoryQuery = "SELECT id FROM users WHERE username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(categoryQuery);
            preparedStatement.setString(1, name);
            ResultSet categoryResultSet = preparedStatement.executeQuery();

            if (categoryResultSet.next()) {
                userId = categoryResultSet.getInt("id");
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userId;
    }
}
