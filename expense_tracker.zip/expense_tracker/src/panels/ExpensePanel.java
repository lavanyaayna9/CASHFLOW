package panels;

import panels.dashboardSubPanels.*;
import util.MySQLConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static authentication.LoginForm.userId;
import static panels.SettingPanel.currentUserCurrency;
import static panels.SettingPanel.currentUserCurrencySymbol;
import static panels.dashboardSubPanels.OverviewPanel.selectedTimePeriod;
import static util.Categories.getCategories;
import static util.Categories.getCategoryIdByName;

public class ExpensePanel extends JPanel {

    private JTextField expenseNameField;
    private JTextField expenseAmountField;
    JComboBox<String> categoryComboBox = new JComboBox<>();

    private JButton saveButton;
    private static JTextArea expenseDisplayArea;

    public ExpensePanel() {
        setLayout(null);

        JLabel nameLabel = new JLabel("Expense Name:");
        expenseNameField = new JTextField();

        JLabel amountLabel = new JLabel("Expense Amount:");
        expenseAmountField = new JTextField();

        JLabel categoryLabel = new JLabel("Expense Category:");
        setCategoryComboBox();

        saveButton = new JButton("Save Expense");


        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);

        nameLabel.setBounds(50, 80, 250, 50);
        nameLabel.setFont(font1);
        expenseNameField.setBounds(300, 80, 300, 50);
        expenseNameField.setFont(font2);

        amountLabel.setBounds(50, 160, 250, 50);
        amountLabel.setFont(font1);
        expenseAmountField.setBounds(300, 160, 300, 50);
        expenseAmountField.setFont(font2);

        categoryLabel.setBounds(50, 240, 250, 50);
        categoryLabel.setFont(font1);
        categoryComboBox.setBounds(300, 240, 300, 50);
        categoryComboBox.setFont(font2);

        saveButton.setBounds(180, 325, 300, 50);
        saveButton.setBackground(Color.decode("#ff6961"));
        saveButton.setFont(font1);

        expenseDisplayArea = new JTextArea();
        expenseDisplayArea.setLineWrap(true); // Enable text wrapping
        JScrollPane scrollPane = new JScrollPane(expenseDisplayArea);
        scrollPane.setBounds(50, 400, 550, 200);
        expenseDisplayArea.setEditable(false);

        expenseDisplayArea.setBackground(Color.WHITE);
        expenseDisplayArea.setFont(new Font("Arial", Font.PLAIN, 16));
        expenseDisplayArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        add(scrollPane);


        // Load and display existing expenses when the panel is created
        loadAndDisplayExpenses();


        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String expenseName = expenseNameField.getText();
                String expenseAmountStr = expenseAmountField.getText();
                String expenseCategory = (String) categoryComboBox.getSelectedItem();

                if (!expenseName.isEmpty() && !expenseAmountStr.isEmpty()) {
                    try {
                        double expenseAmount = Double.parseDouble(expenseAmountStr);
                        Date expenseDate = new Date();

                        if (saveExpense(userId, expenseName, expenseAmount, expenseDate, expenseCategory)) {
                            JOptionPane.showMessageDialog(null, "Expense saved successfully!");
                            expenseNameField.setText("");
                            expenseAmountField.setText("");
                            // updates expenses box
                            loadAndDisplayExpenses();
                        } else {
                            JOptionPane.showMessageDialog(null, "Failed to save expense. Please try again.");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid expense amount. Please enter a valid number.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                }
            }
        });

        add(nameLabel);
        add(expenseNameField);
        add(amountLabel);
        add(expenseAmountField);
        add(categoryLabel);
        add(categoryComboBox);
        add(saveButton);
    }


    public static boolean saveExpense(int userId, String name, double amount, Date date, String expenseCategory) {

        int categoryId = getCategoryIdByName(expenseCategory);

        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "INSERT INTO expenses (user_id, name, amount, datetime, category_id) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            preparedStatement.setString(2, name);
            preparedStatement.setDouble(3, amount);
            Timestamp timestamp = new Timestamp(date.getTime());
            preparedStatement.setTimestamp(4, timestamp);
            preparedStatement.setInt(5, categoryId);

            int rowsAffected = preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();

            OverviewPanel.updateValues(selectedTimePeriod);
            ReportsPanel.updateValues();
            ExpenseIncomePieChartPanel.updateValues(selectedTimePeriod);
            CategoryWisePieChartPanel.updateValues(selectedTimePeriod);
            SplitNotificationPanel.updateValues(selectedTimePeriod);
            SubscriptionNotificationPanel.updateValues(selectedTimePeriod);
            GoalNotificationPanel.updateValues(selectedTimePeriod);

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public static void loadAndDisplayExpenses() {
        expenseDisplayArea.setText("");

        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "SELECT e.name, e.amount, e.datetime, c.category_name FROM expenses e" +
                    " LEFT JOIN categories c on e.category_id = c.category_id WHERE e.user_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            while (resultSet.next()) {
                String expenseName = resultSet.getString("name");
                double expenseAmount = resultSet.getDouble("amount");
                Timestamp timestamp = resultSet.getTimestamp("datetime");
                String categoryName = resultSet.getString("category_name");
                String expenseDate = dateFormat.format(new Date(timestamp.getTime()));

                // Append the expense details to the display area
                expenseDisplayArea.append("Name: " + expenseName + "\n");
                expenseDisplayArea.append("Amount: " + currentUserCurrencySymbol + " " + expenseAmount + "\n");
                expenseDisplayArea.append("Date: " + expenseDate + "\n");
                expenseDisplayArea.append("Category: " + categoryName + "\n");
                expenseDisplayArea.append("------------------------------\n");
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load expenses.");
        }
    }

    public void setCategoryComboBox() {
        categoryComboBox.removeAllItems();

        List<String> categories = getCategories("expense");
        for (String category : categories) {
            categoryComboBox.addItem(category);
        }
    }

}
