package panels.dashboardSubPanels;

import util.MySQLConnection;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static authentication.LoginForm.userId;
import static panels.DashboardPanel.getExpenses;

public class GoalNotificationPanel extends JPanel {

    private static JLabel goalAmountPercentage;
    public int selectedTimePeriod = 3;

    public GoalNotificationPanel() {
        setLayout(null);
        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);

        Double goalAmount = getGoalAmount();
        int goalPercentage = 0;
        if (goalAmount != null) {
            Double expense = getExpenses(selectedTimePeriod);
            goalPercentage = (int) (expense / goalAmount * 100);
        }

        setBounds(10, 560, 300, 90);
        TitledBorder titledBorder = new TitledBorder(new LineBorder(Color.BLACK), "Goal Percentage");
        titledBorder.setTitleFont(font1);
        setBorder(titledBorder);
        goalAmountPercentage = new JLabel();

        if (goalAmount == null) {
            goalAmountPercentage.setText("No Goal Set");
            goalAmountPercentage.setForeground(Color.decode("#4ba3c4"));
            goalAmountPercentage.setBounds(90, 40, 180, 30);
        } else if (goalPercentage > 100) {
            goalAmountPercentage.setText(goalPercentage + "%");
            goalAmountPercentage.setForeground(Color.decode("#ff6961"));
            goalAmountPercentage.setBounds(120, 40, 180, 30);
        } else if (goalPercentage < 100) {
            goalAmountPercentage.setText(goalPercentage + "%");
            goalAmountPercentage.setForeground(Color.decode("#77DD77"));
            goalAmountPercentage.setBounds(120, 40, 180, 30);
        }

        goalAmountPercentage.setFont(font1);
        add(goalAmountPercentage);
    }

    public static Double getGoalAmount() {
        Double amount = null;
        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "SELECT goal_amount FROM user_settings WHERE user_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                amount = resultSet.getDouble(1);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load goal amount.");
        }
        return amount;
    }

    public static void updateValues(int days) {
        Double goalAmount = getGoalAmount();
        int goalPercentage = 0;
        if (goalAmount != null) {
            Double expense = getExpenses(days);
            goalPercentage = (int) (expense / goalAmount * 100);
        }

        if (goalAmount == null) {
            goalAmountPercentage.setText("No Goal Set");
            goalAmountPercentage.setForeground(Color.decode("#4ba3c4"));
            goalAmountPercentage.setBounds(90, 40, 180, 30);
        } else if (goalPercentage > 100) {
            goalAmountPercentage.setText(goalPercentage + "%");
            goalAmountPercentage.setForeground(Color.decode("#ff6961"));
            goalAmountPercentage.setBounds(120, 40, 180, 30);
        } else if (goalPercentage < 100) {
            goalAmountPercentage.setText(goalPercentage + "%");
            goalAmountPercentage.setForeground(Color.decode("#77DD77"));
            goalAmountPercentage.setBounds(120, 40, 180, 30);
        }
    }


}
