package panels.dashboardSubPanels;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;

import static panels.DashboardPanel.getExpenses;
import static panels.DashboardPanel.getIncomes;
import static panels.SettingPanel.currentUserCurrencySymbol;

public class OverviewPanel extends JPanel {
    public static int selectedTimePeriod = 3;
    public static JLabel expensesDataField;
    public static JLabel incomesDataField;

    public OverviewPanel() {
        setLayout(null);
        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);

        float expenses = Math.round(getExpenses(selectedTimePeriod));
        float incomes = Math.round(getIncomes(selectedTimePeriod));

        setBounds(10, 50, 300, 130);
        TitledBorder titledBorder = new TitledBorder(new LineBorder(Color.BLACK), "Overview");
        titledBorder.setTitleFont(font1);
        setBorder(titledBorder);


        JLabel expensesLabel = new JLabel("Expenses: ");
        expensesLabel.setBounds(20, 40, 100, 30);
        expensesLabel.setFont(font1);

        JLabel incomesLabel = new JLabel("Incomes: ");
        incomesLabel.setBounds(20, 80, 100, 30);
        incomesLabel.setFont(font1);

        expensesDataField = new JLabel();
        expensesDataField.setBounds(120, 40, 150, 30);
        expensesDataField.setFont(font2);
        expensesDataField.setText(String.valueOf(expenses));

        incomesDataField = new JLabel();
        incomesDataField.setBounds(110, 80, 150, 30);
        incomesDataField.setFont(font2);
        incomesDataField.setText(String.valueOf(incomes));


        add(expensesLabel);
        add(expensesDataField);
        add(incomesLabel);
        add(incomesDataField);
    }

    public static void updateValues(int days) {
        selectedTimePeriod = days;
        float expenses = Math.round(getExpenses(selectedTimePeriod));
        float incomes = Math.round(getIncomes(selectedTimePeriod));
        expensesDataField.setText(currentUserCurrencySymbol + " " + expenses);
        incomesDataField.setText(currentUserCurrencySymbol + " " + incomes);
    }


}
