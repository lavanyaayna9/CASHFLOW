package panels.dashboardSubPanels;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

import static panels.DashboardPanel.getCategoryWiseData;


public class CategoryWisePieChartPanel extends JPanel {

    static DefaultPieDataset dataset;
    private JFreeChart chart;
    private ChartPanel chartPanel;

    public CategoryWisePieChartPanel() {
        setBounds(320, 340, 320, 300);

        dataset = createDataset();
        chart = createChart(dataset);
        chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(320, 300));
        add(chartPanel);
    }

    private DefaultPieDataset createDataset() {
        DefaultPieDataset dataset = new DefaultPieDataset();

        Map<String, Double> categoryData = getCategoryWiseData(3);

        for (Map.Entry<String, Double> entry : categoryData.entrySet()) {
            dataset.setValue(entry.getKey(), entry.getValue());
        }

        return dataset;
    }

    private JFreeChart createChart(DefaultPieDataset dataset) {
        JFreeChart pieChart = ChartFactory.createPieChart("category", dataset, false, true, false);
        return pieChart;
    }

    public static void updateValues(int days) {
        Map<String, Double> categoryData = getCategoryWiseData(days);
        if (categoryData.isEmpty()) {
            dataset.clear();
        } else {
            dataset.clear();
            for (Map.Entry<String, Double> entry : categoryData.entrySet()) {
                dataset.setValue(entry.getKey(), entry.getValue());
            }
        }
    }
}
