package panels.dashboardSubPanels;

import util.MySQLConnection;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static authentication.LoginForm.userId;

public class SubscriptionNotificationPanel extends JPanel {

    private static JLabel subscriptionCountLabel;
    public static int selectedTimePeriod = 3;

    public SubscriptionNotificationPanel() {
        setLayout(null);
        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);

        int subscriptions = subscriptionCount(selectedTimePeriod);

        setBounds(10, 380, 300, 160);
        TitledBorder titledBorder = new TitledBorder(new LineBorder(Color.BLACK), "Subscriptions");
        titledBorder.setTitleFont(font1);
        setBorder(titledBorder);
        subscriptionCountLabel = new JLabel();
        if (subscriptions > 0) {
            subscriptionCountLabel.setText("You have " + subscriptions + " Subscriptions.");
            subscriptionCountLabel.setBounds(35, 70, 250, 30);
            subscriptionCountLabel.setForeground(Color.decode("#ff6961"));
        } else {
            subscriptionCountLabel.setText("No subscriptions");
            subscriptionCountLabel.setBounds(75, 70, 180, 30);
            subscriptionCountLabel.setForeground(Color.decode("#77DD77"));
        }
        subscriptionCountLabel.setFont(font1);
        add(subscriptionCountLabel);
    }

    public static int subscriptionCount(int selectedTimePeriod) {
        int count = 0;
        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "SELECT count(*) FROM expenses e" +
                    " LEFT JOIN expense_tracker.categories c on c.category_id = e.category_id" +
                    " WHERE e.user_id = ? AND c.category_name = 'Subscription' AND e.datetime >= DATE_SUB(NOW(), INTERVAL ? DAY)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, selectedTimePeriod);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load Subscriptions.");
        }
        return count;
    }

    public static void updateValues(int days) {
        selectedTimePeriod = days;
        int subscriptions = subscriptionCount(days);
        if (subscriptions > 0) {
            subscriptionCountLabel.setText("You have " + subscriptions + " Subscriptions.");
            subscriptionCountLabel.setBounds(35, 70, 250, 30);
            subscriptionCountLabel.setForeground(Color.decode("#ff6961"));
        } else {
            subscriptionCountLabel.setText("No subscriptions");
            subscriptionCountLabel.setBounds(75, 70, 180, 30);
            subscriptionCountLabel.setForeground(Color.decode("#77DD77"));
        }
    }


}
