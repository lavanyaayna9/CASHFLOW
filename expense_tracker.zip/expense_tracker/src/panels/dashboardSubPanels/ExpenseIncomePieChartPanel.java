package panels.dashboardSubPanels;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import java.awt.*;

import static panels.DashboardPanel.getExpenses;
import static panels.DashboardPanel.getIncomes;


public class ExpenseIncomePieChartPanel extends JPanel {

    static DefaultPieDataset dataset;
    private JFreeChart chart;
    private ChartPanel chartPanel;

    public ExpenseIncomePieChartPanel() {
        setBounds(320, 55, 320, 280);

        dataset = createDataset();
        chart = createChart(dataset);
        chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(320, 280));
        add(chartPanel);
    }

    private DefaultPieDataset createDataset() {
        Double expensesDataset = getExpenses(3);
        Double incomesDataset = getIncomes(3);
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Expenses", expensesDataset);
        dataset.setValue("Income", incomesDataset);
        return dataset;
    }

    private JFreeChart createChart(DefaultPieDataset dataset) {
        JFreeChart pieChart = ChartFactory.createPieChart(null, dataset, false, true, false);
        return pieChart;
    }

    public static void updateValues(int days) {
        Double expensesDataset = getExpenses(days);
        Double incomesDataset = getIncomes(days);
        dataset.setValue("Expenses", expensesDataset);
        dataset.setValue("Income", incomesDataset);
    }
}
