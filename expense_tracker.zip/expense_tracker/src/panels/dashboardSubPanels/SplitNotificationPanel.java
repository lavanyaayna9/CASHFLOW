package panels.dashboardSubPanels;

import util.MySQLConnection;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static authentication.LoginForm.userId;

public class SplitNotificationPanel extends JPanel {

    private static JLabel splitCountLabel;
    public static int selectedTimePeriod = 3;

    public SplitNotificationPanel() {
        setLayout(null);
        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);

        int splits = splitCount(selectedTimePeriod);

        setBounds(10, 200, 300, 160);
        TitledBorder titledBorder = new TitledBorder(new LineBorder(Color.BLACK), "Splits");
        titledBorder.setTitleFont(font1);
        setBorder(titledBorder);
        splitCountLabel = new JLabel();
        splitCountLabel.setForeground(Color.decode("#4ba3c4"));
        if (splits > 0) {
            splitCountLabel.setText("You have " + splits + " Splits.");
            splitCountLabel.setBounds(60, 70, 180, 30);
        } else {
            splitCountLabel.setText("No new splits");
            splitCountLabel.setBounds(90, 70, 180, 30);
        }
        splitCountLabel.setFont(font1);
        add(splitCountLabel);
    }

    public static int splitCount(int selectedTimePeriod) {
        int count = 0;
        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "SELECT count(*) FROM expenses e" +
                    " LEFT JOIN expense_tracker.categories c on c.category_id = e.category_id" +
                    " WHERE e.user_id = ? AND c.category_name = 'Split' AND e.datetime >= DATE_SUB(NOW(), INTERVAL ? DAY)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, selectedTimePeriod);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load incomes.");
        }
        return count;
    }

    public static void updateValues(int days) {
        selectedTimePeriod = days;
        int splits = splitCount(days);
        if (splits > 0) {
            splitCountLabel.setText("You have " + splits + " Splits.");
            splitCountLabel.setBounds(60, 70, 180, 30);

        } else {
            splitCountLabel.setText("No new splits");
            splitCountLabel.setBounds(90, 70, 180, 30);

        }
    }


}
