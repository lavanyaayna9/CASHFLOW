package panels;

import panels.dashboardSubPanels.CategoryWisePieChartPanel;
import panels.dashboardSubPanels.ExpenseIncomePieChartPanel;
import panels.dashboardSubPanels.OverviewPanel;
import util.MySQLConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static authentication.LoginForm.userId;
import static panels.SettingPanel.currentUserCurrency;
import static panels.SettingPanel.currentUserCurrencySymbol;
import static panels.dashboardSubPanels.OverviewPanel.selectedTimePeriod;
import static util.Categories.getCategories;
import static util.Categories.getCategoryIdByName;

public class IncomePanel extends JPanel {

    private JTextField incomeNameField;
    private JTextField incomeAmountField;
    JComboBox<String> categoryComboBox = new JComboBox<>();

    private JButton saveButton;
    private static JTextArea incomeDisplayArea;

    public IncomePanel() {
        setLayout(null);

        JLabel nameLabel = new JLabel("Income Name:");
        incomeNameField = new JTextField();

        JLabel amountLabel = new JLabel("Income Amount:");
        incomeAmountField = new JTextField();

        JLabel categoryLabel = new JLabel("Income Category:");
        setCategoryComboBox();

        saveButton = new JButton("Save Income");


        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);

        nameLabel.setBounds(50, 80, 250, 50);
        nameLabel.setFont(font1);
        incomeNameField.setBounds(300, 80, 300, 50);
        incomeNameField.setFont(font2);

        amountLabel.setBounds(50, 160, 250, 50);
        amountLabel.setFont(font1);
        incomeAmountField.setBounds(300, 160, 300, 50);
        incomeAmountField.setFont(font2);

        categoryLabel.setBounds(50, 240, 250, 50);
        categoryLabel.setFont(font1);
        categoryComboBox.setBounds(300, 240, 300, 50);
        categoryComboBox.setFont(font2);

        saveButton.setBounds(180, 325, 300, 50);
        saveButton.setBackground(Color.decode("#77DD77"));
        saveButton.setFont(font1);

        incomeDisplayArea = new JTextArea();
        incomeDisplayArea.setLineWrap(true); // Enable text wrapping
        JScrollPane scrollPane = new JScrollPane(incomeDisplayArea);
        scrollPane.setBounds(50, 400, 550, 200);
        incomeDisplayArea.setEditable(false);

        incomeDisplayArea.setBackground(Color.WHITE);
        incomeDisplayArea.setFont(new Font("Arial", Font.PLAIN, 16));
        incomeDisplayArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        add(scrollPane);


        // Load and display existing incomes when the panel is created
        loadAndDisplayIncomes();


        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String incomeName = incomeNameField.getText();
                String incomeAmountStr = incomeAmountField.getText();
                String incomeCategory = (String) categoryComboBox.getSelectedItem();

                if (!incomeName.isEmpty() && !incomeAmountStr.isEmpty()) {
                    try {
                        double incomeAmount = Double.parseDouble(incomeAmountStr);
                        Date incomeDate = new Date();

                        if (saveIncome(userId, incomeName, incomeAmount, incomeDate, incomeCategory)) {
                            JOptionPane.showMessageDialog(null, "Income saved successfully!");
                            incomeNameField.setText("");
                            incomeAmountField.setText("");
                            // updates incomes box
                            loadAndDisplayIncomes();
                        } else {
                            JOptionPane.showMessageDialog(null, "Failed to save income. Please try again.");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid income amount. Please enter a valid number.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                }
            }
        });

        add(nameLabel);
        add(incomeNameField);
        add(amountLabel);
        add(incomeAmountField);
        add(categoryLabel);
        add(categoryComboBox);
        add(saveButton);
    }


    public boolean saveIncome(int userId, String name, double amount, Date date, String incomeCategory) {

        int categoryId = getCategoryIdByName(incomeCategory);

        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "INSERT INTO incomes (user_id, name, amount, datetime, category_id) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            preparedStatement.setString(2, name);
            preparedStatement.setDouble(3, amount);
            Timestamp timestamp = new Timestamp(date.getTime());
            preparedStatement.setTimestamp(4, timestamp);
            preparedStatement.setInt(5, categoryId);

            int rowsAffected = preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();

            OverviewPanel.updateValues(selectedTimePeriod);
            ExpenseIncomePieChartPanel.updateValues(selectedTimePeriod);
            CategoryWisePieChartPanel.updateValues(selectedTimePeriod);
            ReportsPanel.updateValues();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public static void loadAndDisplayIncomes() {
        incomeDisplayArea.setText("");

        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "SELECT i.name, i.amount, i.datetime, c.category_name FROM incomes i" +
                    " LEFT JOIN categories c on i.category_id = c.category_id WHERE i.user_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            while (resultSet.next()) {
                String incomeName = resultSet.getString("name");
                double incomeAmount = resultSet.getDouble("amount");
                Timestamp timestamp = resultSet.getTimestamp("datetime");
                String categoryName = resultSet.getString("category_name");
                String incomeDate = dateFormat.format(new Date(timestamp.getTime()));


                // Append the income details to the display area
                incomeDisplayArea.append("Name: " + incomeName + "\n");
                incomeDisplayArea.append("Amount: " + currentUserCurrencySymbol + " " + incomeAmount + "\n");
                incomeDisplayArea.append("Date: " + incomeDate + "\n");
                incomeDisplayArea.append("Category: " + categoryName + "\n");
                incomeDisplayArea.append("------------------------------\n");
            }

            resultSet.close();
            preparedStatement.close();

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load incomes.");
        }
    }

    public void setCategoryComboBox() {
        categoryComboBox.removeAllItems();

        List<String> categories = getCategories("income");
        for (int i = 0; i < categories.size(); i++) {
            categoryComboBox.addItem(categories.get(i));
        }
    }

}
