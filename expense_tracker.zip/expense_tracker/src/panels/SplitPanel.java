package panels;

import com.toedter.calendar.JDateChooser;
import panels.dashboardSubPanels.*;
import util.MySQLConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Date;
import java.util.List;

import static authentication.LoginForm.userId;
import static panels.DashboardPanel.days;
import static panels.ExpensePanel.saveExpense;
import static panels.SettingPanel.currentUserCurrencySymbol;
import static panels.dashboardSubPanels.OverviewPanel.selectedTimePeriod;
import static util.Users.getAllUserNames;
import static util.Users.getUserIdByUsername;

public class SplitPanel extends JPanel {

    private JTextField splitNameField;
    private JTextField splitAmountField;
    private JTextField splitDescriptionField;
    private JDateChooser dateChooser;
    JList<String> userList;
    DefaultListModel<String> userListModel;

    private JButton saveButton;
    private static JTextArea splitDisplayArea;

    public SplitPanel() {
        setLayout(null);

        JLabel nameLabel = new JLabel("Split Name:");
        splitNameField = new JTextField();

        JLabel amountLabel = new JLabel("Split Amount:");
        splitAmountField = new JTextField();

        JLabel descriptionLabel = new JLabel("Split Description:");
        splitDescriptionField = new JTextField();

        JLabel userLabel = new JLabel("Split Among:");

        JLabel dateLabel = new JLabel("Split Date:");
        dateChooser = new JDateChooser();

        saveButton = new JButton("Save Split");


        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);
        Font font3 = new Font("Arial", Font.PLAIN, 15);


        nameLabel.setBounds(50, 40, 250, 40);
        nameLabel.setFont(font1);
        splitNameField.setBounds(300, 40, 300, 40);
        splitNameField.setFont(font2);

        amountLabel.setBounds(50, 100, 250, 40);
        amountLabel.setFont(font1);
        splitAmountField.setBounds(300, 100, 300, 40);
        splitAmountField.setFont(font2);

        descriptionLabel.setBounds(50, 160, 250, 40);
        descriptionLabel.setFont(font1);
        splitDescriptionField.setBounds(300, 160, 300, 40);
        splitDescriptionField.setFont(font2);

        dateLabel.setBounds(50, 220, 250, 40);
        dateLabel.setFont(font1);
        dateChooser.setBounds(300, 220, 300, 40);
        dateChooser.setFont(font2);

        userLabel.setBounds(50, 280, 250, 40);
        userLabel.setFont(font1);

        List<String> usernames = getAllUserNames();
        userListModel = new DefaultListModel<>();
        for (int i = 0; i < usernames.size(); i++) {
            userListModel.addElement(usernames.get(i));
        }
        userList = new JList<>(userListModel);
        userList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        userList.setFont(font2);

        JScrollPane userScrollPane = new JScrollPane(userList);
        userScrollPane.setBounds(300, 280, 300, 100);

        saveButton.setBounds(180, 400, 300, 40);
        saveButton.setBackground(Color.decode("#ff6961"));
        saveButton.setFont(font1);

        splitDisplayArea = new JTextArea();
        splitDisplayArea.setLineWrap(true); // Enable text wrapping
        JScrollPane scrollPane = new JScrollPane(splitDisplayArea);
        scrollPane.setBounds(50, 460, 550, 140);
        splitDisplayArea.setEditable(false);

        splitDisplayArea.setBackground(Color.WHITE);
        splitDisplayArea.setFont(new Font("Arial", Font.PLAIN, 16));
        splitDisplayArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        add(scrollPane);


        // Load and display existing splits when the panel is created
        loadAndDisplaySplits();


        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String splitName = splitNameField.getText();
                String splitAmountStr = splitAmountField.getText();
                String splitDescription = splitDescriptionField.getText();
                List<String> splitUsers = userList.getSelectedValuesList();

                if (!splitName.isEmpty() && !splitAmountStr.isEmpty()) {
                    try {
                        double splitAmount = Double.parseDouble(splitAmountStr);
                        java.util.Date splitDate = dateChooser.getDate();

                        if (saveSplit(userId, splitName, splitAmount, splitDate, splitDescription, splitUsers)) {
                            JOptionPane.showMessageDialog(null, "Split saved successfully!");
                            splitNameField.setText("");
                            splitDescriptionField.setText("");
                            splitAmountField.setText("");

                            // updates splits box
                            loadAndDisplaySplits();
                        } else {
                            JOptionPane.showMessageDialog(null, "Failed to save split. Please try again.");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid split amount. Please enter a valid number.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                }
            }
        });

        add(nameLabel);
        add(splitNameField);
        add(amountLabel);
        add(splitAmountField);
        add(descriptionLabel);
        add(splitDescriptionField);
        add(dateLabel);
        add(dateChooser);
        add(userLabel);
        add(userScrollPane);
        add(saveButton);
    }


    public boolean saveSplit(int userId, String name, double amount, Date date, String description, List<String> splitUsers) {

        try {
            Connection connection = MySQLConnection.getConnection();
            String splitQuery = "INSERT INTO splits (user_id, split_name, split_description, amount) VALUES (?, ?, ?, ?)";
            PreparedStatement splitPreparedStatement = connection.prepareStatement(splitQuery, Statement.RETURN_GENERATED_KEYS);
            splitPreparedStatement.setInt(1, userId);
            splitPreparedStatement.setString(2, name);
            splitPreparedStatement.setString(3, description);
            splitPreparedStatement.setDouble(4, amount);

            int splitRowsAffected = splitPreparedStatement.executeUpdate();

            int splitId = -1;
            ResultSet generatedKeys = splitPreparedStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                splitId = generatedKeys.getInt(1);
            }
            splitPreparedStatement.close();

            int splitAssignmentRowsAffected = 0;
            for (int i = 0; i < splitUsers.size(); i++) {
                int splitUserId = getUserIdByUsername(splitUsers.get(i));
                String splitAssignmentQuery = "INSERT INTO split_assignments (split_id, split_receiver_id) VALUES(?, ?)";
                PreparedStatement splitAssignmentPreparedStatement = connection.prepareStatement(splitAssignmentQuery);

                splitAssignmentPreparedStatement.setInt(1, splitId);
                splitAssignmentPreparedStatement.setInt(2, splitUserId);

                splitAssignmentRowsAffected += splitAssignmentPreparedStatement.executeUpdate();
                splitAssignmentPreparedStatement.close();

                double splitAmount = Math.round(amount / splitUsers.size());
                saveExpense(splitUserId, name, splitAmount, date, "Split");
            }
            connection.close();

            SplitNotificationPanel.updateValues(selectedTimePeriod);
            OverviewPanel.updateValues(selectedTimePeriod);
            ReportsPanel.updateValues();
            ExpensePanel.loadAndDisplayExpenses();
            CategoryWisePieChartPanel.updateValues(selectedTimePeriod);
            ExpenseIncomePieChartPanel.updateValues(selectedTimePeriod);
            GoalNotificationPanel.updateValues(selectedTimePeriod);


            return splitRowsAffected > 0 && splitAssignmentRowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public static void loadAndDisplaySplits() {
        splitDisplayArea.setText("");

        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "SELECT s.split_name, s.split_description," +
                    " s.amount / COUNT(sa.assignment_id) AS amount, GROUP_CONCAT(u2.username) AS receiver_usernames" +
                    " FROM splits s LEFT JOIN split_assignments sa ON s.split_id = sa.split_id" +
                    " LEFT JOIN users u1 ON s.user_id = u1.id LEFT JOIN users u2 ON sa.split_receiver_id = u2.id" +
                    " where s.user_id = ?" +
                    " GROUP BY s.split_id, s.split_name, s.split_description, s.amount, u1.username;";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String splitName = resultSet.getString("split_name");
                String splitDescription = resultSet.getString("split_description");
                double splitAmount = resultSet.getDouble("amount");
                String splitUsers = resultSet.getString("receiver_usernames");

                // Append the split details to the display area
                splitDisplayArea.append("Name: " + splitName + "\n");
                splitDisplayArea.append("Description: " + splitDescription + "\n");
                splitDisplayArea.append("Amount(per person): " + currentUserCurrencySymbol + " " + splitAmount + "\n");
                splitDisplayArea.append("Split among: " + splitUsers + "\n");
                splitDisplayArea.append("------------------------------\n");
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load splits.");
        }
    }
}
