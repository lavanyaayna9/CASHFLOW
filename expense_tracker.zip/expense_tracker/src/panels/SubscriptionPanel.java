package panels;

import com.toedter.calendar.JDateChooser;
import panels.dashboardSubPanels.*;
import util.MySQLConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static authentication.LoginForm.userId;
import static panels.SettingPanel.currentUserCurrencySymbol;
import static panels.dashboardSubPanels.OverviewPanel.selectedTimePeriod;
import static util.Categories.getCategoryIdByName;

public class SubscriptionPanel extends JPanel {


    private JTextField subscriptionNameField;
    private JTextField subscriptionAmountField;
    private JDateChooser startDateChooser;
    private JDateChooser endDateChooser;
    JComboBox<String> recurringTypeComboBox;
    private JButton saveButton;
    private static JTextArea subscriptionDisplayArea;

    String[] recurringTypes = {"Daily", "Weekly", "Monthly", "Yearly"};


    public SubscriptionPanel() {
        setLayout(null);

        JLabel nameLabel = new JLabel("Subscription Name:");
        subscriptionNameField = new JTextField();

        JLabel amountLabel = new JLabel("Subscription Amount:");
        subscriptionAmountField = new JTextField();

        JLabel recurringTypeLabel = new JLabel("Subscription Type:");
        recurringTypeComboBox = new JComboBox<>(recurringTypes);

        JLabel startDateLabel = new JLabel("Subscription Start Date:");
        startDateChooser = new JDateChooser();

        JLabel endDateLabel = new JLabel("Subscription End Date:");
        endDateChooser = new JDateChooser();

        saveButton = new JButton("Save Subscription");


        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);
        Font font3 = new Font("Arial", Font.PLAIN, 16);


        nameLabel.setBounds(50, 40, 250, 40);
        nameLabel.setFont(font1);
        subscriptionNameField.setBounds(300, 40, 300, 40);
        subscriptionNameField.setFont(font2);

        amountLabel.setBounds(50, 100, 250, 40);
        amountLabel.setFont(font1);
        subscriptionAmountField.setBounds(300, 100, 300, 40);
        subscriptionAmountField.setFont(font2);

        recurringTypeLabel.setBounds(50, 160, 250, 40);
        recurringTypeLabel.setFont(font1);
        recurringTypeComboBox.setBounds(300, 160, 300, 40);
        recurringTypeComboBox.setFont(font2);

        startDateLabel.setBounds(50, 220, 250, 40);
        startDateLabel.setFont(font1);
        startDateChooser.setBounds(300, 220, 300, 40);
        startDateChooser.setFont(font2);

        endDateLabel.setBounds(50, 280, 250, 40);
        endDateLabel.setFont(font1);
        endDateChooser.setBounds(300, 280, 300, 40);
        endDateChooser.setFont(font2);

        saveButton.setBounds(180, 340, 300, 40);
        saveButton.setBackground(Color.decode("#ff6961"));
        saveButton.setFont(font1);

        subscriptionDisplayArea = new JTextArea();
        subscriptionDisplayArea.setLineWrap(true); // Enable text wrapping
        JScrollPane scrollPane = new JScrollPane(subscriptionDisplayArea);
        scrollPane.setBounds(50, 400, 550, 200);
        subscriptionDisplayArea.setEditable(false);

        subscriptionDisplayArea.setBackground(Color.WHITE);
        subscriptionDisplayArea.setFont(font3);
        subscriptionDisplayArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        add(scrollPane);

        // Load and display existing subscriptions when the panel is created
        loadAndDisplaySubscriptions();


        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String subscriptionName = subscriptionNameField.getText();
                String subscriptionAmountStr = subscriptionAmountField.getText();
                String subscriptionType = (String) recurringTypeComboBox.getSelectedItem();
                java.util.Date subscriptionStartDate = startDateChooser.getDate();
                java.util.Date subscriptionEndDate = endDateChooser.getDate();

                if (!subscriptionName.isEmpty() && !subscriptionAmountStr.isEmpty() && !subscriptionType.isEmpty()
                        && subscriptionStartDate != null && subscriptionEndDate != null) {
                    double subscriptionAmount = Double.parseDouble(subscriptionAmountStr);
                    try {
                        if (saveSubscription(userId, subscriptionName, subscriptionAmount, subscriptionStartDate,
                                subscriptionEndDate, subscriptionType)) {
                            JOptionPane.showMessageDialog(null, "Subscription saved successfully!");
                            subscriptionNameField.setText("");
                            subscriptionAmountField.setText("");
                            // updates expenses box
                            loadAndDisplaySubscriptions();
                        } else {
                            JOptionPane.showMessageDialog(null, "Failed to save subscription. Please try again.");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid subscription amount. Please enter a valid number.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                }
            }
        });

        add(nameLabel);
        add(subscriptionNameField);
        add(amountLabel);
        add(subscriptionAmountField);
        add(recurringTypeLabel);
        add(recurringTypeComboBox);
        add(startDateLabel);
        add(startDateChooser);
        add(endDateLabel);
        add(endDateChooser);
        add(saveButton);
    }


    public boolean saveSubscription(int userId, String name, double amount, Date startDate, Date endDate,
                                    String subscriptionType) {
        int subscriptionNumber;
        if ("Weekly".equals(subscriptionType)) {
            subscriptionNumber = 7;
        } else if ("Monthly".equals(subscriptionType)) {
            subscriptionNumber = 30;
        } else if ("Yearly".equals(subscriptionType)) {
            subscriptionNumber = 365;
        } else {
            subscriptionNumber = 1;
        }
        int categoryId = getCategoryIdByName("Subscription");
        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "INSERT INTO expenses (user_id, name, amount, datetime, category_id) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            preparedStatement.setString(2, name);
            preparedStatement.setDouble(3, amount);

            // Calculate the datetime based on the subscription type
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startDate);
            java.sql.Date subscriptionDate = new java.sql.Date(calendar.getTime().getTime());

            while (subscriptionDate.before(endDate)) {
                preparedStatement.setDate(4, subscriptionDate);
                preparedStatement.setInt(5, categoryId);

                int subscriptionRowsAffected = preparedStatement.executeUpdate();

                calendar.add(Calendar.DAY_OF_MONTH, subscriptionNumber);
                subscriptionDate = new java.sql.Date(calendar.getTime().getTime());

                if (subscriptionRowsAffected <= 0) {
                    preparedStatement.close();
                    connection.close();
                    return false;
                }
            }

            preparedStatement.close();
            connection.close();

            SubscriptionNotificationPanel.updateValues(selectedTimePeriod);
            OverviewPanel.updateValues(selectedTimePeriod);
            ReportsPanel.updateValues();
            ExpensePanel.loadAndDisplayExpenses();
            CategoryWisePieChartPanel.updateValues(selectedTimePeriod);
            ExpenseIncomePieChartPanel.updateValues(selectedTimePeriod);
            GoalNotificationPanel.updateValues(selectedTimePeriod);
            
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public static void loadAndDisplaySubscriptions() {
        subscriptionDisplayArea.setText("");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "SELECT e.name, e.amount, e.datetime FROM expenses e" +
                    " LEFT JOIN categories c on e.category_id = c.category_id" +
                    " WHERE e.user_id = ? and c.category_name = 'Subscription'";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String subscriptionName = resultSet.getString("name");
                double subscriptionAmount = resultSet.getDouble("amount");
                Timestamp timestamp = resultSet.getTimestamp("datetime");
                String subscriptionDate = dateFormat.format(new Date(timestamp.getTime()));


                // Append the subscription details to the display area
                subscriptionDisplayArea.append("Name: " + subscriptionName + "\n");
                subscriptionDisplayArea.append("Amount: " + currentUserCurrencySymbol + " " + subscriptionAmount + "\n");
                subscriptionDisplayArea.append("Subscription Date: " + subscriptionDate + "\n");
                subscriptionDisplayArea.append("------------------------------\n");
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load subscriptions.");
        }
    }
}
