package panels;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static authentication.LoginForm.userId;
import static panels.DashboardPanel.getExpenses;
import static panels.DashboardPanel.getIncomes;
import static util.Categories.getCategoryNameById;
import static util.MySQLConnection.getConnection;

public class ReportsPanel extends JPanel {

    public static JPanel chartPanel = new JPanel();

    static JFreeChart chart1 = expenseIncomeChart();
    static JFreeChart chart2 = expenseTrackerChart();
    static JFreeChart chart3 = incomeTrackerChart();

    public ReportsPanel() {

        setLayout(new BorderLayout());

        ChartPanel expenseIncomeChartPanel = new ChartPanel(chart1);
        ChartPanel expenseTrackerChartPanel = new ChartPanel(chart2);
        ChartPanel incomeTrackerChartPanel = new ChartPanel(chart3);

        Dimension preferredSize = new Dimension(400, 300);
        expenseIncomeChartPanel.setPreferredSize(preferredSize);
        expenseTrackerChartPanel.setPreferredSize(preferredSize);
        incomeTrackerChartPanel.setPreferredSize(preferredSize);

        chartPanel.setLayout(new BoxLayout(chartPanel, BoxLayout.Y_AXIS));
        chartPanel.add(expenseIncomeChartPanel);
        chartPanel.add(expenseTrackerChartPanel);
        chartPanel.add(incomeTrackerChartPanel);

        JScrollPane scrollPane = new JScrollPane(chartPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        add(scrollPane, BorderLayout.CENTER);
    }

    private static JFreeChart expenseIncomeChart() {

        // Create dataset
        CategoryDataset dataset = expenseIncomeDataset();

        // Create chart
        JFreeChart chart = ChartFactory.createBarChart(
                "Last 30 Days Incomes and Expenses",
                "Dates",
                "Amount",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        CategoryPlot plot = (CategoryPlot) chart.getPlot();
        NumberAxis yAxis = (NumberAxis) plot.getRangeAxis();
        yAxis.setTickUnit(new NumberTickUnit(300));
        CategoryAxis xAxis = plot.getDomainAxis();
        xAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);


        plot.setDatasetRenderingOrder(DatasetRenderingOrder.FORWARD);
        return chart;
    }

    private static JFreeChart expenseTrackerChart() {
        CategoryDataset dataset = expenseTrackerDataset();

        JFreeChart chart = ChartFactory.createStackedBarChart(
                "Expense Tracker",
                "Date",
                "Amount",
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false
        );

        CategoryPlot plot = chart.getCategoryPlot();

        CategoryAxis categoryAxis = plot.getDomainAxis();
        categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);

        NumberAxis yAxis = (NumberAxis) plot.getRangeAxis();
        yAxis.setTickUnit(new NumberTickUnit(300));
        return chart;
    }

    private static JFreeChart incomeTrackerChart() {
        CategoryDataset dataset = incomeTrackerDataset();

        JFreeChart chart = ChartFactory.createStackedBarChart(
                "Income Tracker",
                "Date",
                "Amount",
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false
        );

        CategoryPlot plot = chart.getCategoryPlot();

        CategoryAxis categoryAxis = plot.getDomainAxis();
        categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);

        NumberAxis yAxis = (NumberAxis) plot.getRangeAxis();
        yAxis.setTickUnit(new NumberTickUnit(300));
        return chart;
    }

    private static CategoryDataset expenseIncomeDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try {
            Connection connection = getConnection();

            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DAY_OF_MONTH, -30);
            Date startDate = calendar.getTime();
            Date endDate = new Date();

            PreparedStatement incomeStatement = connection.prepareStatement("SELECT datetime, SUM(amount) as total " +
                    "FROM incomes WHERE user_id = ? and datetime BETWEEN ? AND ? GROUP BY datetime order by datetime");
            incomeStatement.setInt(1, userId);
            incomeStatement.setTimestamp(2, new java.sql.Timestamp(startDate.getTime()));
            incomeStatement.setTimestamp(3, new java.sql.Timestamp(endDate.getTime()));
            ResultSet incomeResultSet = incomeStatement.executeQuery();

            PreparedStatement expenseStatement = connection.prepareStatement("SELECT datetime, -SUM(amount) as total " +
                    "FROM expenses WHERE user_id = ? and datetime BETWEEN ? AND ? GROUP BY datetime order by datetime");
            expenseStatement.setInt(1, userId);
            expenseStatement.setTimestamp(2, new java.sql.Timestamp(startDate.getTime()));
            expenseStatement.setTimestamp(3, new java.sql.Timestamp(endDate.getTime()));
            ResultSet expenseResultSet = expenseStatement.executeQuery();

            Calendar dateIterator = Calendar.getInstance();
            dateIterator.setTime(startDate);

            while (dateIterator.getTime().compareTo(endDate) <= 0) {
                Date currentDate = dateIterator.getTime();
                dataset.addValue(0.0, "Expense", formatDate(currentDate));
                dataset.addValue(0.0, "Income", formatDate(currentDate));

                dateIterator.add(Calendar.DAY_OF_MONTH, 1);
            }

            while (incomeResultSet.next()) {
                Date date = incomeResultSet.getTimestamp("datetime");
                dataset.addValue(incomeResultSet.getDouble("total"), "Income", formatDate(date));
            }

            while (expenseResultSet.next()) {
                Date date = expenseResultSet.getTimestamp("datetime");
                dataset.addValue(expenseResultSet.getDouble("total"), "Expense", formatDate(date));
            }


            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return dataset;
    }

    private static CategoryDataset expenseTrackerDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try {
            Connection connection = getConnection();
            PreparedStatement expenseStatement = connection.prepareStatement("SELECT datetime, category_id, amount " +
                    "FROM expenses where user_id = ? order by datetime desc");
            expenseStatement.setInt(1, userId);
            ResultSet resultSet = expenseStatement.executeQuery();

            while (resultSet.next()) {
                java.sql.Date date = resultSet.getDate("datetime");
                int categoryId = resultSet.getInt("category_id");
                double amount = resultSet.getDouble("amount");

                String categoryName = getCategoryNameById(categoryId);
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM");
                String dateStr = dateFormat.format(date);

                dataset.addValue(amount, categoryName, dateStr);
            }

            resultSet.close();
            expenseStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return dataset;
    }

    private static CategoryDataset incomeTrackerDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try {
            Connection connection = getConnection();
            PreparedStatement incomeStatement = connection.prepareStatement("SELECT datetime, category_id, amount " +
                    "FROM incomes where user_id = ? order by datetime desc");
            incomeStatement.setInt(1, userId);
            ResultSet resultSet = incomeStatement.executeQuery();

            while (resultSet.next()) {
                java.sql.Date date = resultSet.getDate("datetime");
                int categoryId = resultSet.getInt("category_id");
                double amount = resultSet.getDouble("amount");

                String categoryName = getCategoryNameById(categoryId);
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM");
                String dateStr = dateFormat.format(date);

                dataset.addValue(amount, categoryName, dateStr);
            }

            resultSet.close();
            incomeStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return dataset;
    }

    public static void updateValues() {
        chart1 = expenseIncomeChart();
        chart2 = expenseTrackerChart();
        chart3 = incomeTrackerChart();

        ChartPanel expenseIncomeChartPanel = (ChartPanel) chartPanel.getComponent(0);
        ChartPanel expenseTrackerChartPanel = (ChartPanel) chartPanel.getComponent(1);
        ChartPanel incomeTrackerChartPanel = (ChartPanel) chartPanel.getComponent(2);

        expenseIncomeChartPanel.setChart(chart1);
        expenseTrackerChartPanel.setChart(chart2);
        incomeTrackerChartPanel.setChart(chart3);

        chartPanel.repaint();
    }


    private static String formatDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM");
        return sdf.format(date);
    }

}
