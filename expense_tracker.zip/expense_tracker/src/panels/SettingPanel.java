package panels;

import panels.dashboardSubPanels.CategoryWisePieChartPanel;
import panels.dashboardSubPanels.ExpenseIncomePieChartPanel;
import panels.dashboardSubPanels.OverviewPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static authentication.LoginForm.userId;
import static util.Categories.*;
import static util.MySQLConnection.getConnection;

public class SettingPanel extends JPanel {

    private DefaultListModel<String> expensesModel;
    private DefaultListModel<String> incomesModel;
    private JList<String> expensesList;
    private JList<String> incomesList;

    static JComboBox<String> currencyCombobox = new JComboBox<>(new String[]{"INR", "USD", "EURO"});
    static String currentUserCurrency = getCurrencySetting();
    public static String currentUserCurrencySymbol;

    JTextField goalField = new JTextField(20);


    public SettingPanel() {
        setLayout(null);
        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);
        Font font3 = new Font("Arial", Font.BOLD, 15);


        List<String> expenses = getCategories("expense");
        List<String> incomes = getCategories("income");
        List<String> defaultCategories = getDefaultCategories();

        expensesModel = new DefaultListModel<>();
        incomesModel = new DefaultListModel<>();
        for (int i = 0; i < expenses.size(); i++) {
            expensesModel.addElement(expenses.get(i));
        }
        for (int i = 0; i < incomes.size(); i++) {
            incomesModel.addElement(incomes.get(i));
        }

        expensesList = new JList<>(expensesModel);
        expensesList.setFont(font3);

        incomesList = new JList<>(incomesModel);
        incomesList.setFont(font3);

        // Create "Expense" category panel
        JLabel expenseLabel = new JLabel("Expense Categories");
        expenseLabel.setFont(font1);
        expenseLabel.setBounds(80, 10, 280, 30);

        JScrollPane expenseScrollPane = new JScrollPane(expensesList);
        expenseScrollPane.setBounds(30, 40, 280, 120);

        JTextField expenseCategoryField = new JTextField(20);
        expenseCategoryField.setFont(font2);
        expenseCategoryField.setBounds(30, 170, 280, 30);

        JButton expenseAddButton = new JButton("Add");
        expenseAddButton.setBackground(Color.decode("#77DD77"));
        expenseAddButton.setFont(font1);
        expenseAddButton.setBounds(35, 210, 120, 30);

        JButton expenseRemoveButton = new JButton("Remove");
        expenseRemoveButton.setBackground(Color.decode("#ff6961"));
        expenseRemoveButton.setFont(font1);
        expenseRemoveButton.setBounds(180, 210, 120, 30);

        // Create "Income" category panel
        JLabel incomeLabel = new JLabel("Income  Categories");
        incomeLabel.setFont(font1);
        incomeLabel.setBounds(380, 10, 280, 30);

        JScrollPane incomeScrollPane = new JScrollPane(incomesList);
        incomeScrollPane.setBounds(330, 40, 280, 120);

        JTextField incomeCategoryField = new JTextField(20);
        incomeCategoryField.setFont(font2);
        incomeCategoryField.setBounds(330, 170, 280, 30);

        JButton incomeAddButton = new JButton("Add");
        incomeAddButton.setBackground(Color.decode("#77DD77"));
        incomeAddButton.setFont(font1);
        incomeAddButton.setBounds(345, 210, 120, 30);

        JButton incomeRemoveButton = new JButton("Remove");
        incomeRemoveButton.setBackground(Color.decode("#ff6961"));
        incomeRemoveButton.setFont(font1);
        incomeRemoveButton.setBounds(480, 210, 120, 30);

        expenseAddButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newCategory = expenseCategoryField.getText().trim();
                if (!newCategory.isEmpty() && !expensesModel.contains(newCategory)
                        && addCategory("expense", newCategory)) {
                    expenseCategoryField.setText("");
                    expensesModel.addElement(newCategory);
                    ExpensePanel.loadAndDisplayExpenses();
                    JOptionPane.showMessageDialog(null, "Category saved successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to save category. Please try again.");
                }
            }
        });

        expenseRemoveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedIndex = expensesList.getSelectedIndex();
                String selectedItem = expensesList.getSelectedValue();

                if (defaultCategories.contains(selectedItem)) {
                    JOptionPane.showMessageDialog(null, "Cannot delete default category.");
                } else if (selectedIndex >= 0 && removeCategory("expense", selectedItem)) {
                    expensesModel.remove(selectedIndex);
                    ExpensePanel.loadAndDisplayExpenses();
                    JOptionPane.showMessageDialog(null, "Category deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to delete category. Please try again.");
                }
            }
        });

        incomeAddButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newCategory = incomeCategoryField.getText().trim();
                if (!newCategory.isEmpty() && !incomesModel.contains(newCategory)
                        && addCategory("income", newCategory)) {
                    incomeCategoryField.setText("");
                    incomesModel.addElement(newCategory);
                    IncomePanel.loadAndDisplayIncomes();
                    JOptionPane.showMessageDialog(null, "Category saved successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to save category. Please try again.");
                }
            }
        });

        incomeRemoveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedIndex = incomesList.getSelectedIndex();
                String selectedItem = incomesList.getSelectedValue();

                if (defaultCategories.contains(selectedItem)) {
                    JOptionPane.showMessageDialog(null, "Cannot delete default category.");
                } else if (selectedIndex >= 0 && removeCategory("income", selectedItem)) {
                    incomesModel.remove(selectedIndex);
                    IncomePanel.loadAndDisplayIncomes();
                    JOptionPane.showMessageDialog(null, "Category deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to delete category. Please try again.");
                }
            }
        });

        JLabel goalLabel = new JLabel("Goal Amount:");

        Double goalAmount = getGoalAmount();
        if (goalAmount != null) {
            goalField.setText(String.valueOf(goalAmount));
        } else {
            goalField.setText("");
        }

        JButton goalButton = new JButton("Submit");


        goalLabel.setFont(font1);
        goalLabel.setBounds(30, 300, 150, 40);
        goalField.setFont(font2);
        goalField.setBounds(180, 300, 200, 40);

        goalButton.setBackground(Color.decode("#77DD77"));
        goalButton.setFont(font1);
        goalButton.setBounds(400, 300, 200, 40);

        goalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String goalAmountStr = goalField.getText();

                if (!goalAmountStr.isEmpty()) {
                    try {
                        double goalAmount = Double.parseDouble(goalAmountStr);

                        if (saveGoal(userId, goalAmount)) {
                            JOptionPane.showMessageDialog(null, "Goal saved successfully!");
                        } else {
                            JOptionPane.showMessageDialog(null, "Failed to save goal. Please try again.");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid goal amount. Please enter a valid number.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please provide goal amount.");
                }
            }
        });

        JLabel currencyLabel = new JLabel("Currency: ");
        currencyLabel.setFont(font1);
        currencyLabel.setBounds(30, 360, 250, 40);

        currencyCombobox.setBounds(300, 360, 250, 40);
        currencyCombobox.setFont(font1);
        String userCurrency = currentUserCurrency.toUpperCase();
        currencyCombobox.setSelectedItem(userCurrency);

        currencyCombobox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String currency = (String) currencyCombobox.getSelectedItem();

                    if (saveCurrency(userId, currency)) {
                        updateAmountsCurrency(currency.toLowerCase());
                        currentUserCurrency = getCurrencySetting();
                        updateCurrencyUI(currency);
                        JOptionPane.showMessageDialog(null, "Currency updated successfully!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to update currency. Please try again.");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Failed to update currency. Please try again.");
                }
            }
        });

        add(expenseLabel);
        add(expenseScrollPane);
        add(expenseCategoryField);
        add(expenseAddButton);
        add(expenseRemoveButton);
        add(incomeLabel);
        add(incomeScrollPane);
        add(incomeCategoryField);
        add(incomeAddButton);
        add(incomeRemoveButton);
        add(goalLabel);
        add(goalField);
        add(goalButton);
        add(currencyLabel);
        add(currencyCombobox);
    }

    private boolean saveGoal(Integer userId, Double goalAmount) {
        try (Connection connection = getConnection()) {
            // Check if the user_id already exists in the user_settings table
            String checkQuery = "SELECT user_setting_id FROM user_settings WHERE user_id = ?";
            PreparedStatement checkStatement = connection.prepareStatement(checkQuery);
            checkStatement.setInt(1, userId);

            ResultSet resultSet = checkStatement.executeQuery();

            if (resultSet.next()) {
                // User_id exists, update the goal amount
                int userSettingId = resultSet.getInt("user_setting_id");
                String updateQuery = "UPDATE user_settings SET goal_amount = ? WHERE user_setting_id = ?";
                PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
                updateStatement.setDouble(1, goalAmount);
                updateStatement.setInt(2, userSettingId);
                updateStatement.executeUpdate();
                return true;
            } else {
                // User_id doesn't exist, insert a new entry
                String insertQuery = "INSERT INTO user_settings (goal_amount, user_id) VALUES (?, ?)";
                PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
                insertStatement.setDouble(1, goalAmount);
                insertStatement.setInt(2, userId);
                insertStatement.executeUpdate();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private Double getGoalAmount() {
        Double goalAmount = null;
        try (Connection connection = getConnection()) {
            String query = "SELECT goal_amount FROM user_settings WHERE user_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                goalAmount = resultSet.getDouble(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return goalAmount;
    }

    private boolean addCategory(String type, String categoryName) {
        try {
            Connection connection = getConnection();
            String query = "INSERT INTO categories (category_name, category_type, user_id) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, categoryName);
            preparedStatement.setString(2, type);
            preparedStatement.setInt(3, userId);

            int rowsAffected = preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean removeCategory(String type, String categoryName) {
        try {
            // update all expense attached to this category to none
            Connection connection = getConnection();

            int noneCategory = getCategoryIdByName("None");
            int toDeleteCategory = getCategoryIdByName(categoryName);

            String updateQuery = "UPDATE expenses SET category_id = ? WHERE category_id = ?";
            PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
            updateStatement.setInt(1, noneCategory);
            updateStatement.setInt(2, toDeleteCategory);
            updateStatement.executeUpdate();

            String deleteQuery = "DELETE FROM categories WHERE category_name = ? and category_type = ? and user_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.setString(1, categoryName);
            preparedStatement.setString(2, type);
            preparedStatement.setInt(3, userId);

            int rowsAffected = preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean saveCurrency(Integer userId, String currency) {
        try (Connection connection = getConnection()) {
            // Check if the user_id already exists in the user_settings table
            String checkQuery = "SELECT user_setting_id FROM user_settings WHERE user_id = ?";
            PreparedStatement checkStatement = connection.prepareStatement(checkQuery);
            checkStatement.setInt(1, userId);

            ResultSet resultSet = checkStatement.executeQuery();

            if (resultSet.next()) {
                int userSettingId = resultSet.getInt("user_setting_id");
                String updateQuery = "UPDATE user_settings SET currency = ? WHERE user_setting_id = ?";
                PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
                updateStatement.setString(1, currency);
                updateStatement.setInt(2, userSettingId);
                updateStatement.executeUpdate();
            } else {
                // User_id doesn't exist, insert a new entry
                String insertQuery = "INSERT INTO user_settings (currency, user_id) VALUES (?, ?)";
                PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
                insertStatement.setString(1, currency);
                insertStatement.setInt(2, userId);
                insertStatement.executeUpdate();
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private static String getCurrencySetting() {
        String currency = null;
        try (Connection connection = getConnection()) {
            String query = "SELECT currency FROM user_settings WHERE user_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                currency = resultSet.getString(1);
                if (currency.equalsIgnoreCase("inr")) {
                    currentUserCurrencySymbol = "₹";
                } else if (currency.equalsIgnoreCase("usd")) {
                    currentUserCurrencySymbol = "$";
                } else if (currency.equalsIgnoreCase("euro")) {
                    currentUserCurrencySymbol = "€";
                }
            } else {
                currency = "inr";
                currentUserCurrencySymbol = "₹";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return currency;
    }

    private void updateAmountsCurrency(String updatedCurrency) {
        updatedCurrency = updatedCurrency.toLowerCase();
        double rate;
        if (currentUserCurrency.equals("inr") && updatedCurrency.equals("usd")) {
            rate = 0.012;
        } else if (currentUserCurrency.equals("inr") && updatedCurrency.equals("euro")) {
            rate = 0.011;
        } else if (currentUserCurrency.equals("usd") && updatedCurrency.equals("inr")) {
            rate = 83.30;
        } else if (currentUserCurrency.equals("usd") && updatedCurrency.equals("euro")) {
            rate = 0.93;
        } else if (currentUserCurrency.equals("euro") && updatedCurrency.equals("inr")) {
            rate = 89.26;
        } else if (currentUserCurrency.equals("euro") && updatedCurrency.equals("usd")) {
            rate = 1.07;
        } else {
            rate = 1D;
        }

        System.out.println("rate = " + rate);


        try (Connection connection = getConnection()) {
            String updateExpenseQuery = "UPDATE expenses SET amount = amount * ? WHERE user_id = ?";
            PreparedStatement updateExpenseStatement = connection.prepareStatement(updateExpenseQuery);
            updateExpenseStatement.setDouble(1, rate);
            updateExpenseStatement.setInt(2, userId);
            updateExpenseStatement.executeUpdate();

            String updateIncomeQuery = "UPDATE incomes SET amount = amount * ? WHERE user_id = ?";
            PreparedStatement updateIncomeStatement = connection.prepareStatement(updateIncomeQuery);
            updateIncomeStatement.setDouble(1, rate);
            updateIncomeStatement.setInt(2, userId);
            updateIncomeStatement.executeUpdate();

            String updateGoalAmountQuery = "UPDATE user_settings SET goal_amount = goal_amount * ? WHERE user_id = ?";
            PreparedStatement updateGoalAmountStatement = connection.prepareStatement(updateGoalAmountQuery);
            updateGoalAmountStatement.setDouble(1, rate);
            updateGoalAmountStatement.setInt(2, userId);
            updateGoalAmountStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateCurrencyUI(String updateCurrency) {
        // settings
        Double goalAmount = getGoalAmount();
        if (goalAmount != null) {
            goalField.setText(String.valueOf(goalAmount));
        } else {
            goalField.setText("");
        }

        //dashboard
        int days = DashboardPanel.days;
        CategoryWisePieChartPanel.updateValues(days);
        ExpenseIncomePieChartPanel.updateValues(days);
        OverviewPanel.updateValues(days);
        ExpensePanel.loadAndDisplayExpenses();
        IncomePanel.loadAndDisplayIncomes();
        SplitPanel.loadAndDisplaySplits();
        SubscriptionPanel.loadAndDisplaySubscriptions();
        ReportsPanel.updateValues();
    }


}
