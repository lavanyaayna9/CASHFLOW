package panels;

import panels.dashboardSubPanels.*;
import util.MySQLConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import static authentication.LoginForm.userId;

public class DashboardPanel extends JPanel {

    private ExpenseIncomePieChartPanel expenseIncomePieChartPanel;
    private CategoryWisePieChartPanel categoryWisePieChartPanel;
    static JComboBox<String> timePeriodComboBox = new JComboBox<>(new String[]{"3 days", "7 days", "14 days", "30 days"});

    static Integer days = 3;


    public DashboardPanel() {
        setLayout(null);
        OverviewPanel overviewPanel = new OverviewPanel();
        expenseIncomePieChartPanel = new ExpenseIncomePieChartPanel();
        categoryWisePieChartPanel = new CategoryWisePieChartPanel();
        SplitNotificationPanel splitNotificationPanel = new SplitNotificationPanel();
        GoalNotificationPanel goalNotificationPanel = new GoalNotificationPanel();
        SubscriptionNotificationPanel subscriptionNotificationPanel = new SubscriptionNotificationPanel();

        Font font1 = new Font("Arial", Font.BOLD, 18);
        Font font2 = new Font("Arial", Font.PLAIN, 18);

        JLabel timePeriodLabel = new JLabel("Time Period: ");
        timePeriodLabel.setFont(font1);
        timePeriodLabel.setBounds(150, 5, 200, 30);

        timePeriodComboBox.setBounds(350, 5, 200, 30);
        timePeriodComboBox.setFont(font1);


        timePeriodComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String period = (String) timePeriodComboBox.getSelectedItem();
                int selectedTimePeriod = period != null ? Integer.parseInt(period.split(" ")[0]) : 0;
                days = selectedTimePeriod;
                OverviewPanel.updateValues(selectedTimePeriod);
                splitNotificationPanel.updateValues(selectedTimePeriod);
                subscriptionNotificationPanel.updateValues(selectedTimePeriod);
                ExpenseIncomePieChartPanel.updateValues(selectedTimePeriod);
                CategoryWisePieChartPanel.updateValues(selectedTimePeriod);
                goalNotificationPanel.updateValues(selectedTimePeriod);
            }
        });

        add(overviewPanel);
        add(expenseIncomePieChartPanel);
        add(categoryWisePieChartPanel);
        add(splitNotificationPanel);
        add(subscriptionNotificationPanel);
        add(goalNotificationPanel);
        add(timePeriodLabel);
        add(timePeriodComboBox);
    }

    public static Double getExpenses(int days) {
        double expenses = 0D;
        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "SELECT sum(amount) FROM expenses WHERE user_id = ? AND datetime >= DATE_SUB(NOW(), INTERVAL ? DAY);";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, days);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                expenses = resultSet.getDouble(1);
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load expenses.");
        }
        return expenses;
    }

    public static Double getIncomes(int days) {
        double incomes = 0D;
        try {
            Connection connection = MySQLConnection.getConnection();
            String query = "SELECT sum(amount) FROM incomes WHERE user_id = ? AND datetime >= DATE_SUB(NOW(), INTERVAL ? DAY);";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, days);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                incomes = resultSet.getDouble(1);
            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load incomes.");
        }
        return incomes;
    }

    public static Map<String, Double> getCategoryWiseData(int days) {
        Map<String, Double> categoryAmount = new HashMap<>();
        try {
            Connection connection = MySQLConnection.getConnection();
            String expenseQuery = "select c.category_name , sum(e.amount) from categories c" +
                    " left join expenses e on c.category_id = e.category_id" +
                    " where c.category_type = 'expense' AND e.user_id = ? AND (c.user_id IS NULL OR c.user_id = ?)" +
                    " and e.`datetime` >= DATE_SUB(NOW(), INTERVAL ? DAY)" +
                    " group by c.category_id";
            PreparedStatement expensePreparedStatement = connection.prepareStatement(expenseQuery);
            expensePreparedStatement.setInt(1, userId);
            expensePreparedStatement.setInt(2, userId);
            expensePreparedStatement.setInt(3, days);
            ResultSet expenseResult = expensePreparedStatement.executeQuery();

            while (expenseResult.next()) {
                categoryAmount.put("Expense(" + expenseResult.getString(1) + ")",
                        expenseResult.getDouble(2));
            }
            expenseResult.close();
            expensePreparedStatement.close();

            String incomeQuery = "select c.category_name , sum(i.amount) from categories c" +
                    " left join incomes i on c.category_id = i.category_id" +
                    " where c.category_type = 'income' AND i.user_id = ? AND (c.user_id IS NULL OR c.user_id = ?)" +
                    " and i.`datetime` >= DATE_SUB(NOW(), INTERVAL ? DAY)" +
                    " group by c.category_id";
            PreparedStatement incomePreparedStatement = connection.prepareStatement(incomeQuery);
            incomePreparedStatement.setInt(1, userId);
            incomePreparedStatement.setInt(2, userId);
            incomePreparedStatement.setInt(3, days);
            ResultSet incomeResult = incomePreparedStatement.executeQuery();

            while (incomeResult.next()) {
                categoryAmount.put("Income (" + incomeResult.getString(1) + ")",
                        incomeResult.getDouble(2));
            }
            incomeResult.close();
            incomePreparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to load category-wise data.");
        }
        return categoryAmount;
    }
}
