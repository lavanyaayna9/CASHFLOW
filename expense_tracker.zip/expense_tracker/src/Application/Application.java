package Application;

import authentication.LoginForm;
import authentication.SignupForm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Application extends JFrame {

    public Application() {
        setTitle("Expense Tracker");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 700);
        setLocationRelativeTo(null);

        ImageIcon imageIcon = new ImageIcon("assets/logo.jpg");
        Image resizedImage = imageIcon.getImage().getScaledInstance(800, 650, Image.SCALE_SMOOTH);
        ImageIcon resizedImageIcon = new ImageIcon(resizedImage);
        JLabel imageLabel = new JLabel(resizedImageIcon);

        JPanel panel = new JPanel(new FlowLayout());
        Font font = new Font("Arial", Font.BOLD, 18);

        JButton signUpButton = new JButton("Sign Up");
        JButton loginButton = new JButton("Login");

        loginButton.setBounds(100, 590, 200, 40);
        loginButton.setBackground(Color.decode("#2dc460"));
        loginButton.setFont(font);

        signUpButton.setBounds(500, 590, 200, 40);
        signUpButton.setBackground(Color.decode("#4ba3c4"));
        signUpButton.setFont(font);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginForm();
                setVisible(false);
            }
        });
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SignupForm();
                dispose();
            }
        });

        imageLabel.add(loginButton);
        imageLabel.add(signUpButton);
        panel.add(imageLabel);
        add(panel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Application application = new Application();
            application.setVisible(true);
        });
    }
}
