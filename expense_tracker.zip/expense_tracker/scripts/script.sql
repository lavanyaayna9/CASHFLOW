-- create db
CREATE DATABASE `expense_tracker`;
use expense_tracker;

-- create tables

-- expense_tracker.users definition
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- expense_tracker.categories definition
CREATE TABLE `categories` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `category_type` enum('expense','income','none') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  KEY `Categories_FK` (`user_id`),
  CONSTRAINT `Categories_FK` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- expense_tracker.expenses definition
CREATE TABLE `expenses` (
  `expense_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `amount` double DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `datetime` datetime NOT NULL,
  `category_id` int DEFAULT '1',
  PRIMARY KEY (`expense_id`),
  KEY `expenses_FK` (`user_id`),
  KEY `expenses_FK_1` (`category_id`),
  CONSTRAINT `expenses_FK` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_FK_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- expense_tracker.incomes definition
CREATE TABLE `incomes` (
  `income_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `amount` double DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `datetime` datetime NOT NULL,
  `category_id` int DEFAULT '1',
  PRIMARY KEY (`income_id`),
  KEY `incomes_FK` (`user_id`),
  KEY `incomes_FK_1` (`category_id`),
  CONSTRAINT `incomes_FK` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `incomes_FK_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- expense_tracker.splits definition
CREATE TABLE `splits` (
  `split_id` int NOT NULL AUTO_INCREMENT,
  `split_name` varchar(100) NOT NULL,
  `split_description` varchar(100) DEFAULT NULL,
  `amount` double NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`split_id`),
  KEY `splits_FK` (`user_id`),
  CONSTRAINT `splits_FK` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- expense_tracker.split_assignments definition
CREATE TABLE `split_assignments` (
  `assignment_id` int NOT NULL AUTO_INCREMENT,
  `split_id` int NOT NULL,
  `split_receiver_id` int DEFAULT NULL,
  PRIMARY KEY (`assignment_id`),
  KEY `split_assignments_FK` (`split_id`),
  KEY `split_assignments_FK_1` (`split_receiver_id`),
  CONSTRAINT `split_assignments_FK` FOREIGN KEY (`split_id`) REFERENCES `splits` (`split_id`),
  CONSTRAINT `split_assignments_FK_1` FOREIGN KEY (`split_receiver_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- expense_tracker.user_settings definition
CREATE TABLE `user_settings` (
  `user_setting_id` int NOT NULL AUTO_INCREMENT,
  `goal_amount` double DEFAULT NULL,
  `user_id` int NOT NULL,
  `currency` enum('usd','inr','euro') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'inr',
  PRIMARY KEY (`user_setting_id`),
  UNIQUE KEY `user_settings_un` (`user_id`),
  CONSTRAINT `user_settings_FK` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- deault entries
INSERT INTO expense_tracker.categories (category_id, category_name, category_type, user_id) VALUES(1, 'None', 'income', NULL);
INSERT INTO expense_tracker.categories (category_id, category_name, category_type, user_id) VALUES(5, 'Food', 'expense', NULL);
INSERT INTO expense_tracker.categories (category_id, category_name, category_type, user_id) VALUES(6, 'Fuel', 'expense', NULL);
INSERT INTO expense_tracker.categories (category_id, category_name, category_type, user_id) VALUES(7, 'Salary', 'income', NULL);
INSERT INTO expense_tracker.categories (category_id, category_name, category_type, user_id) VALUES(8, 'Pocket Money', 'income', NULL);
INSERT INTO expense_tracker.categories (category_id, category_name, category_type, user_id) VALUES(2, 'None', 'expense', NULL);
INSERT INTO expense_tracker.categories (category_id, category_name, category_type, user_id) VALUES(3, 'Split', 'expense', NULL);
INSERT INTO expense_tracker.categories (category_id, category_name, category_type, user_id) VALUES(4, 'Subscription', 'expense', NULL);
